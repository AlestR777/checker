@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
where py >nul 2>nul
if not errorlevel 1 (
    set "PY=py -3"
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo Python 3.11 or newer is required. Install Python from python.org.
        pause
        exit /b 1
    )
    set "PY=python"
)
%PY% -c "import truststore, certifi" >nul 2>nul
if errorlevel 1 (
    echo Installing required certificates libraries for the first run...
    %PY% -m pip install -r requirements.txt
    if errorlevel 1 (
        echo Could not install dependencies. See README_RU.md.
        pause
        exit /b 1
    )
)
echo Starting ThreatWatch locally. Your browser will open automatically.
echo Closing this window stops the app and its 6-hour schedule.
%PY% -m threatwatch desktop
if errorlevel 1 (
    echo Start failed. Check if port 8765 is already in use.
    pause
)
